
export enum MyProducts { 
    "fitored",
    "dora",
    "n_word",
    "canzone",
    "website",
    "brochure"
}

export enum SlideState { "running", "stop" }